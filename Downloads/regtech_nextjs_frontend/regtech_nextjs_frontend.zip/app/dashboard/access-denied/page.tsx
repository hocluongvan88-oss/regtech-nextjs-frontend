import { AccessDenied } from "@/components/auth/access-denied"

export default function AccessDeniedPage() {
  return <AccessDenied />
}
